clc
clear all
close all
%%%% step 1
%%%%%%%load ERA-5 data
%%%load latitude
latt=fopen('latitude.txt');
formatspec='%f %f'; %column
lattt=textscan(latt,formatspec,'Headerlines',1);
latitude=cell2mat(lattt); %convert to matrix
fclose(latt);  
%%%load longitude
longg=fopen('longitude.txt');
formatspec='%f %f';
longgg=textscan(longg,formatspec,'Headerlines',1);
longitude=cell2mat(longgg);
fclose(longg); 
%%%load temperature
tt=fopen('t.txt');
formatspec='%f %f %f %f %f';
ttt=textscan(tt,formatspec,'Headerlines',1);
temperature=cell2mat(ttt);
fclose(tt); 
%%%load geopotential
zz=fopen('z.txt');
formatspec='%f %f %f %f %f';
zzz=textscan(zz,formatspec,'Headerlines',1);
geopotential=cell2mat(zzz);
fclose(zz); 
%%%load Pressurelevel
ll=fopen('level.txt');
formatspec='%f %f';
l=textscan(ll,formatspec,'Headerlines',1);
Pressurelevel=cell2mat(l);
fclose(ll); 
%%%load relative humidity
rr=fopen('r.txt');
formatspec='%f %f %f %f %f';
rrr=textscan(rr,formatspec,'Headerlines',1);
relativehumidity=cell2mat(rrr);
fclose(rr); 
%%%%% Separate the parameters
r=relativehumidity(:,5);
z=geopotential(:,5);
t=temperature(:,5);
lat=latitude(:,1);
long=longitude(:,1);
level=Pressurelevel(:,1);
h=z./(9.8); %%Convert Geopotential to Height

%Creat Meshgrid for 2D Interpolation
[latmeshgrid,longmeshgrid]=meshgrid(lat,long);

%Station coordinates
ydelf=4.3874583;
xdelf=51.9860194;
zdelf=-0.152;
%interp 2D temperature
for i=1:37
    t_layers(1:81,i)=t(i*81-80:i*81,1);    
   for j=1:9
    t_regular(1:9,j,i)=t_layers((9*j)-8:9*j,i);
   end
    t_interp2(i,1:9)=interp2(latmeshgrid,longmeshgrid,t_regular(:,:,i),xdelf,ydelf,'spline');
end

%interp 2D relativehumidity
for i=1:37
    r_layers(1:81,i)=r(i*81-80:i*81,1);
   for j=1:9
    r_regular(1:9,j,i)=r_layers((9*j)-8:9*j,i);
   end
    r_interp2(i,1)=interp2(latmeshgrid,longmeshgrid,r_regular(:,:,i),xdelf,ydelf,'spline');
end

%%%interp 2D Height

for i=1:37
    h_layers(1:81,i)=h(i*81-80:i*81,1);
   for j=1:9
    h_regular(1:9,j,i)=h_layers((9*j)-8:9*j,i);
   end 
    h_interp2(i,1)=interp2(latmeshgrid,longmeshgrid,h_regular(:,:,i),xdelf,ydelf,'spline'); 
end

%%plot internalized parameters
for i=1:37
 mesh(latmeshgrid,longmeshgrid,t_regular(:,:,i));

 mesh(latmeshgrid,longmeshgrid,r_regular(:,:,i));

 mesh(latmeshgrid,longmeshgrid,h_regular(:,:,i));
end

t_interpolation=t_interp2(:,1);
r_interpolation=r_interp2(:,1);
h_interpolation=h_interp2(:,1);

%Calculate the actual water vapor pressure
tcel=t_interpolation-273;   % kelvin-273=celcius
for i=1:37
   Ps(i,1)=6.11*exp(17.27*tcel(i,1)/(237.3+tcel(i,1)));% saturation vapor pressure
   P(i,1)=r_interpolation(i,1)*Ps(i,1)/100; %the actual water vapor pressure
end

%1D interpolation parameters
r_interp=interp1(h_interpolation,r_interpolation,zdelf,'spline'); %Station relativehumidity
t_interp=interp1(h_interpolation,t_interpolation,zdelf,'spline'); %Station temperature
p_interp=interp1(h_interpolation,level,zdelf,'spline');%Station Height

%%%Estimation ZTD
%constant values
k1=77.604;
k2=64.79;
k3=3.776*(10^5);
for i=1:36
    Pmean(i,1)=((P(i,1)+P(i+1,1)))./2; %Average water vapor pressure
    Tmean(i,1)=(((t_interp2(i,1)+t_interp2(i+1,1)))./2);%Average temperature
    Levelmean(i,1)=(level(i,1)+level(i+1,1))./2;%Average pressure Levels
    dz(i,1)=(h_interp2(i+1,1)-h_interp2(i,1)); %Height between layers
    
    Nd(i,1)=k1*(Levelmean(i,1)./(Tmean(i,1))); %Dry tropospheric delay
    Nw(i,1)=k2*(Pmean(i,1)./Tmean(i,1))+k3*(Pmean(i,1)./((Tmean(i,1))^2));%Wet tropospheric delay

    ZTD=(sum(-1*(10^-6*Nd.*dz))+sum(-1*(10^-6*Nw.*dz))); %%-1 because of Delay 
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%% Step 2_____Calculate ZHD using the experimental formula

ZHDs=(0.002277*p_interp)/(1-0.0026*cosd(2*ydelf)-0.00000028*(zdelf));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%Step 3_____Calculate Zenith Wet Delay

ZWD=ZTD-ZHDs;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%Step 4_____read IGS file

DELF=fopen('dlf11790.18zpd');
formatspec='%s %s %f %f %f %f %f %f';
fileIGS=textscan(DELF,formatspec,'Headerlines',44);
fclose(DELF); 
b=fileIGS(:,3);
ZTD_I=b{:,:};
ZTD_IGS=ZTD_I(145,1);
Difference=ZTD_IGS./1000-ZTD; %1000 because of Unit

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Step 5____Calculate Percipitable Water Vapor (PWV)

%%% Calculate Tm
for i=1:36
soorat(i,1)=((P(i,1)+P(i+1,1))/2)/((t_interpolation(i,1)+t_interpolation(i+1,1))/2);
makhraj(i,1)=((P(i,1)+P(i+1,1))/2)/(((t_interpolation(i,1)+t_interpolation(i+1,1))/2)^2);
end
dzz=dz(:,1);
sorat=soorat(:,1).*dzz(:,1);
makh=makhraj(:,1).*dzz(:,1);
sigma_soorat=sum(sorat); % Integral
sigma_makhraj=sum(makh); % Integral
Tm=sigma_soorat./sigma_makhraj;

Rv=461.5; % Gas constant of water vapor
DW=997; %Density water
k_prim=24; 

coefficient=(10^6)/(DW.*Rv.*((k3./Tm)+k_prim));
pwv=coefficient.*ZWD(1,1);

%%%%THE END%%%%
%%Written by Mahdieh Nezamzadeh



